package com.devsu.hackerearth.backend.account.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.devsu.hackerearth.backend.account.model.Transaction;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {

    @Query("Select t from Transaction t where t.accountId = :accountId order by t.date desc")
    List<Transaction> findLastTransactionByAccountId(@Param("accountId") Long accountId);

    @Query("Select t from Transaction t where t.accountId = :accountId and t.date between :dateTransactionStart AND :dateTransactionEnd order by t.date desc")
    List<Transaction> getTransactionsReport(
        @Param("accountId") Long accountId,
        @Param("dateTransactionStart") Date dateTransactionStart,
        @Param("dateTransactionEnd") Date dateTransactionEnd
        );
}

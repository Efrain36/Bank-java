package com.devsu.hackerearth.backend.account.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.account.exception.InsufficientBalanceException;
import com.devsu.hackerearth.backend.account.exception.NotFoundException;
import com.devsu.hackerearth.backend.account.model.Account;
import com.devsu.hackerearth.backend.account.model.Transaction;
import com.devsu.hackerearth.backend.account.model.dto.BankStatementDto;
import com.devsu.hackerearth.backend.account.model.dto.TransactionDto;
import com.devsu.hackerearth.backend.account.repository.AccountRepository;
import com.devsu.hackerearth.backend.account.repository.TransactionRepository;

@Service
public class TransactionServiceImpl implements TransactionService {

    private final TransactionRepository transactionRepository;
    private final AccountRepository accountRepository;

    public TransactionServiceImpl(TransactionRepository transactionRepository, AccountRepository accountRepository) {
        this.transactionRepository = transactionRepository;
        this.accountRepository = accountRepository;
    }

    @Override
    public List<TransactionDto> getAll() {
        // Get all transactions
        return transactionRepository.findAll()
                .stream()
                .map(this::maptoTransactionDto)
                .collect(Collectors.toList());
    }

    @Override
    public TransactionDto getById(Long id) {
        // Get transactions by id
        Transaction transaction = transactionRepository.findById(id).orElseThrow(
                () -> new NotFoundException("La cuenta con id:" + id + " no existe"));

        return maptoTransactionDto(transaction);
    }

    @Override
    public TransactionDto create(TransactionDto transactionDto) {
        // Create transaction
        Account account = accountRepository.findById(transactionDto.getAccountId()).orElseThrow(
                () -> new NotFoundException("Cuenta con id:" + transactionDto.getId() + " no encontrada"));

        Double newBalance;

        TransactionDto lastTransaction = getLastByAccountId(account.getId());

        if (Objects.nonNull(lastTransaction)) {
            System.out.println(lastTransaction);
            newBalance = lastTransaction.getBalance() + transactionDto.getAmount();

        } else {
            newBalance = account.getInitialAmount() + transactionDto.getAmount();
        }

        if (newBalance < 0) {
            throw new InsufficientBalanceException("Saldo no disponible");
        }

        Transaction transaction = Transaction.builder()
                .date(transactionDto.getDate())
                .type(transactionDto.getType())
                .amount(transactionDto.getAmount())
                .balance(newBalance)
                .accountId(transactionDto.getAccountId())
                .build();

        Transaction createdTransaction = transactionRepository.save(transaction);
        transactionDto.setId(createdTransaction.getId());

        return transactionDto;

    }

    @Override
    public List<BankStatementDto> getAllByAccountClientIdAndDateBetween(Long clientId, Date dateTransactionStart,
            Date dateTransactionEnd) {
        List<BankStatementDto> report = new ArrayList<>();
        List<Account> accounts = accountRepository.findAccountsByClient(clientId);

        if (accounts.isEmpty()) {
            return report;
        }

        for (Account account : accounts) {
            List<Transaction> transactions = transactionRepository.getTransactionsReport(account.getId(),
                    dateTransactionStart, dateTransactionEnd);
            List<BankStatementDto> accountStatements = transactions.stream()
                    .map(transaction -> maptoBankStatementDto(account, transaction))
                    .collect(Collectors.toList());
            report.addAll(accountStatements);
        }

        return report;
    }

    @Override
    public TransactionDto getLastByAccountId(Long accountId) {
        // If you need it
        List<Transaction> transactionList = transactionRepository.findLastTransactionByAccountId(accountId);
        if (transactionList.isEmpty()) {
            return null;
        }
        return maptoTransactionDto(transactionList.get(0));
    }

    private TransactionDto maptoTransactionDto(Transaction transaction) {
        return TransactionDto.builder()
                .id(transaction.getId())
                .date(transaction.getDate())
                .type(transaction.getType())
                .amount(transaction.getAmount())
                .balance(transaction.getBalance())
                .build();
    }

    private BankStatementDto maptoBankStatementDto(Account account, Transaction transaction) {
        return BankStatementDto.builder()
                .date(transaction.getDate())
                .client(account.getClientId().toString())
                .accountNumber(account.getNumber())
                .accountType(account.getNumber())
                .initialAmount(account.getInitialAmount())
                .isActive(account.isActive())
                .transactionType(transaction.getAmount() > 0 ? "deposit" : "egress")
                .amount(transaction.getAmount())
                .balance(transaction.getBalance())
                .build();
    }

}

package com.devsu.hackerearth.backend.client.service;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;

import com.devsu.hackerearth.backend.client.exception.NotFoundException;
import com.devsu.hackerearth.backend.client.model.Client;
import com.devsu.hackerearth.backend.client.model.dto.ClientDto;
import com.devsu.hackerearth.backend.client.model.dto.PartialClientDto;
import com.devsu.hackerearth.backend.client.repository.ClientRepository;


@Service
public class ClientServiceImpl implements ClientService {

	private final ClientRepository clientRepository;

	public ClientServiceImpl(ClientRepository clientRepository) {
		this.clientRepository = clientRepository;
	}

	@Override
	public List<ClientDto> getAll() {
		// Get all clients
		return clientRepository.findAll()
				.stream()
				.map(this::mapToClientDto)
				.collect(Collectors.toList());
	}

	@Override
	public ClientDto getById(Long id) {
		// Get clients by id
		Client client = clientRepository.findById(id).orElseThrow(
			() -> new NotFoundException("Cliente con id:" + id + " no encontrado")
		);
		return mapToClientDto(client);
	}

	@Override
	public ClientDto create(ClientDto clientDto) {
		// Create client
		Client client = Client.builder()
				.name(clientDto.getName())
				.dni(clientDto.getDni())
				.gender(clientDto.getGender())
				.age(clientDto.getAge())
				.address(clientDto.getAddress())
				.phone(clientDto.getPhone())
				.password(clientDto.getPassword())
				.isActive(clientDto.isActive())
				.build();

		Client createdClient = clientRepository.save(client);
		clientDto.setId(createdClient.getId());

		return clientDto;
	}

	@Override
	public ClientDto update(ClientDto clientDto) {
		// Update client
		Client client = Client.builder()
				.id(clientDto.getId())
				.name(clientDto.getName())
				.dni(clientDto.getDni())
				.gender(clientDto.getGender())
				.age(clientDto.getAge())
				.address(clientDto.getAddress())
				.phone(clientDto.getPhone())
				.password(clientDto.getPassword())
				.isActive(clientDto.isActive())
				.build();

		clientRepository.save(client);
		return clientDto;
	}

	@Override
	public ClientDto partialUpdate(Long id, PartialClientDto partialClientDto) {
		// Partial update account
		Client client = Client.builder()
				.id(id)
				.isActive(partialClientDto.isActive())
				.build();

		Client updatedClient = clientRepository.save(client);
		return mapToClientDto(updatedClient);
	}

	@Override
	public void deleteById(Long id) {
		// Delete client
		clientRepository.deleteById(id);
	}

	private ClientDto mapToClientDto(Client client) {
		return ClientDto.builder()
				.id(client.getId())
				.dni(client.getDni())
				.name(client.getName())
				.password(client.getPassword())
				.gender(client.getGender())
				.age(client.getAge())
				.address(client.getAddress())
				.phone(client.getPhone())
				.isActive(client.isActive())
				.build();
	}

}